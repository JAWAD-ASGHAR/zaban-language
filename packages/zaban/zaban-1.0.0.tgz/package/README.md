# Zaban

Urdu programming language — Roman Urdu keywords, dynamically typed.

## Install

```bash
npm install zaban
```

## CLI

```bash
npx zaban run program.zbn
```

## API

```typescript
import { runSource } from "zaban";

const output = runSource(`
  shuru
    likho "Salam Dunya"
  khatam
`);

console.log(output.join("\n"));
```

See [KEYWORDS.md](./KEYWORDS.md) for the full language reference.
